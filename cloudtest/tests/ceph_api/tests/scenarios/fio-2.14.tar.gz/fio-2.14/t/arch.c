#include "../arch/arch.h"

unsigned long arch_flags = 0;
int tsc_reliable;
int arch_random;
