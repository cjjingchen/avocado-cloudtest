int main(void)
{
	__asm__ __volatile__("nop;");

	return 0;
}

